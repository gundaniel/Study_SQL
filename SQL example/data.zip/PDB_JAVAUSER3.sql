
--1. 학번, 학생명, 학과번호, 학과명 출력 쿼리문
SELECT SD_NUM 학번, SD_NAME 학생명 , S.S_NUM 학과번호, S_NAME 학과명
FROM STUDENT S INNER JOIN SUBJECT J 
ON S.S_NUM = J.S_NUM;

--위 예제를 서브 쿼리로 변환 
-------------------------------------------------------
--학교 학과명, 학과 소속 학생, 아이디 출력
SELECT S_NAME 학과명, SD_NAME 소속학생, SD_ID 아이디
FROM STUDENT S INNER JOIN SUBJECT D 
ON D.S_NUM = S.S_NUM;

--SELECT SD_NAME, 

SELECT * FROM ENROLLMENT;



SELECT * FROM STUDENT;

UPDATE STUDENT
SET S_NUM  = '02'
WHERE NO = 6;
------------------------------------------------------------

--우리 학교 전체 학과명과 그 학과에 소속된 학생명, 아이디를 출력하도록 쿼리문을 작성해주세요

SELECT S_NAME AS 학과명, SD_NAME AS 학생명, SD_ID AS 아이디
FROM STUDENT S, SUBJECT J;

------------------------------------------------------------
--3. 학과에 소속된 학생 수를 출력하도록 쿼리문 작성해 주세요.

--<1> 학과와 학생수를 출력
SELECT S_NUM, COUNT (SD_NUM)
FROM STUDENT
GROUP BY S_NUM
ORDER BY 1;

--<2> 학과명과 학생수를 출력
SELECT S_NAME 학과명, COUNT(SD_NUM) 학생수
FROM SUBJECT SB INNER JOIN STUDENT ST
ON SB.S_NUM = ST.S_NUM
GROUP BY S_NAME, SB.S_NUM
ORDER BY SB.S_NUM;

------------------------------------------------------------
CREATE OR REPLACE VIEW VIEW_STUDENT
AS
SELECT SD_NUN, SD_NAME, S_NAME
FROM STUDENT S INNER JOIN SUBJECT J
ON S.S_NUM = J.S_NUM;


SELECT * FROM BOOKS;

DELETE FROM BOOKS;

-- 학과번호를 자동으로 구하는 쿼리문을 작성해 주세요.