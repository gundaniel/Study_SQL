-- 일반적인 테이블로 출력(로우가 27개 출력됨)
SELECT 24 *60 *60
FROM DEPARTMENTS;

SELECT 24 * 60 * 60
FROM DUAL;